package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.myapplication.events.DataBaseHelperEvents;
import com.example.myapplication.events.Event;
import com.example.myapplication.login.DatabaseHelper;
import com.example.myapplication.login.User;

public class AddEventOrg extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event_org);

       EditText title = findViewById(R.id.title_input);
       EditText type = findViewById(R.id.type_input);
       EditText price = findViewById(R.id.prix_input);
       EditText description = findViewById(R.id.desription_input);
       EditText date = findViewById(R.id.date_input);
       EditText fs= findViewById(R.id.fs_input);
       EditText bs = findViewById(R.id.bs_input);
       EditText ms = findViewById(R.id.ms_input);
       Button btn = findViewById(R.id.btnSubmit);


       /*btn.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {

               MyDBhelperEvents myDB  = new MyDBhelperEvents(AddEventOrg.this);
               myDB.addEvent(title.getText().toString().trim(),type.getText().toString().trim(),
                       Integer.valueOf(price.getText().toString().trim()),description.getText().toString().trim(),
                       date.getText().toString().trim(), Integer.valueOf(fs.getText().toString().trim()),
                       Integer.valueOf(bs.getText().toString().trim()), Integer.valueOf(ms.getText().toString().trim())
                       );

           }
       });


        */
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DataBaseHelperEvents databaseHelp = new DataBaseHelperEvents(AddEventOrg.this);
                Event event = new Event();

                if (!databaseHelp.checkEvent(title.toString().trim())){
                    event.setTitle(title.getText().toString().trim());
                    event.setType(type.getText().toString().trim());
                    event.setPrix(Integer.valueOf(price.getText().toString().trim()));
                    event.setDescription(description.getText().toString().trim());
                    event.setDate(date.getText().toString().trim());
                    event.setSeat1(Integer.valueOf(fs.getText().toString().trim()));
                    event.setSeat2(Integer.valueOf(ms.getText().toString().trim()));
                    event.setSeat3(Integer.valueOf(bs.getText().toString().trim()));

                    databaseHelp.addEvent(event);
                    Toast.makeText(AddEventOrg.this, "Event Added Successfully", Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(AddEventOrg.this, EventsListe.class);
                    startActivity(i);

                } else {
                    // show error message that record already exists
                    Toast.makeText(AddEventOrg.this, "Change name of event", Toast.LENGTH_SHORT).show();

                }

            }
        });
    }
}