package com.example.myapplication;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.TextView;

import com.example.myapplication.adapters.EventRecyclerAdapter;
import com.example.myapplication.adapters.UserRecyclerAdapter;
import com.example.myapplication.events.DataBaseHelperEvents;
import com.example.myapplication.events.Event;
import com.example.myapplication.login.DatabaseHelper;
import com.example.myapplication.login.User;

import java.util.ArrayList;
import java.util.List;

public class EventsListe extends AppCompatActivity {



            private AppCompatActivity activity = com.example.myapplication.EventsListe.this;
            private TextView textViewName;
            private RecyclerView recyclerViewEvents;
            private List<Event> listevents;
            private EventRecyclerAdapter eventsRecyclerAdapter;
            private DataBaseHelperEvents databaseHelper;
            @Override
            protected void onCreate(@Nullable Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                setContentView(R.layout.activity_events_liste);
                getSupportActionBar().setTitle("");
                initViews();
                initObjects();
            }
            /**
             * This method is to initialize views
             */
            private void initViews() {
                //textViewName = (TextView) findViewById(R.id.textViewName);
                recyclerViewEvents = (RecyclerView) findViewById(R.id.recyclerViewUsers);
            }
            /**
             * This method is to initialize objects to be used
             */
            private void initObjects() {
                listevents = new ArrayList<>();
                eventsRecyclerAdapter = new EventRecyclerAdapter(listevents);
                RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
                recyclerViewEvents.setLayoutManager(mLayoutManager);
                recyclerViewEvents.setItemAnimator(new DefaultItemAnimator());
                recyclerViewEvents.setHasFixedSize(true);
                recyclerViewEvents.setAdapter(eventsRecyclerAdapter);

                databaseHelper = new DataBaseHelperEvents(activity);

                getDataFromSQLite();
            }
            /**
             * This method is to fetch all user records from SQLite
             */
            private void getDataFromSQLite() {
                // AsyncTask is used that SQLite operation not blocks the UI Thread.
                new AsyncTask<Void, Void, Void>() {
                    @Override
                    protected Void doInBackground(Void... params) {
                        listevents.clear();
                        listevents.addAll(databaseHelper.getAllEvents());
                        return null;
                    }
                    @Override
                    protected void onPostExecute(Void aVoid) {
                        super.onPostExecute(aVoid);
                        eventsRecyclerAdapter.notifyDataSetChanged();
                    }
                }.execute();
            }
        }

