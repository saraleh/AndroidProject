package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.login.DatabaseHelper;
import com.example.myapplication.login.inputValidation;

public class LoginOrg extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_org);
        EditText emailEdt= findViewById(R.id.etEmailorg2);
        EditText passwordEdt = findViewById(R.id.etpswdorg2);
        Button signin=  findViewById(R.id.idBtnSigninOrg);
        inputValidation inputValidation = new inputValidation(LoginOrg.this);




        signin.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (!inputValidation.isInputEditTextFilled(emailEdt, getString(R.string.error_message_email))) {
                            return;
                        }
                        if (!inputValidation.isInputEditTextEmail(emailEdt,  getString(R.string.error_message_email))) {
                            return;
                        }
                        if (!inputValidation.isInputEditTextFilled(passwordEdt,  getString(R.string.error_message_email))) {
                            return;
                        }
                        DatabaseHelper databaseHelper = new DatabaseHelper(LoginOrg.this);
                        if (databaseHelper.checkUser(emailEdt.getText().toString().trim()
                                , passwordEdt.getText().toString().trim())) {
                            Intent accountsIntent = new Intent(LoginOrg.this, MenuOrg.class);
                            accountsIntent.putExtra("EMAIL", emailEdt.getText().toString().trim());
                            emailEdt.setText(null);
                            emailEdt.setText(null);
                            startActivity(accountsIntent);
                        } else {
                            // Snack Bar to show success message that record is wrong
                            //Snackbar.make(nestedScrollView, getString(R.string.error_valid_email_password), Snackbar.LENGTH_LONG).show();
                            Toast.makeText(LoginOrg.this,R.string.error_valid_email_password, Toast.LENGTH_LONG).show();
                        }
                    }

                });


    }
}
