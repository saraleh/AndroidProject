package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ManageEventsOrg extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_events_org);

        Button btnadd = findViewById(R.id.btnAddEvOrg);
        Button btnup = findViewById(R.id.btnEdtEv);
        Button btndel = findViewById(R.id.btnDtEv);

        btnadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ManageEventsOrg.this, AddEventOrg.class);
                startActivity(intent);

            }
        });
        btnup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i2 = new Intent(ManageEventsOrg.this, EditEventOrg.class);
                startActivity(i2);
            }
        });
    }

}