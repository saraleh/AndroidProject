package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.myapplication.login.DatabaseHelper;

public class MenuUser extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_user);

        Button bfindname = findViewById(R.id.btnSearchName);
        EditText edtname = findViewById(R.id.edtSearchName);
        Button bfindloc= findViewById(R.id.btnSearchLoc);
        EditText edtloc = findViewById(R.id.edtSearchLoc);

        bfindname.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MenuUser.this, MyEventsUser.class);
                i.putExtra("findname", edtname.getText().toString() );
                startActivity(i);


                }
        });

        bfindloc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MenuUser.this, MyEventsUserByLoc.class);
                i.putExtra("findloc", edtloc.getText().toString());
                startActivity(i);
            }
        });


    }
}