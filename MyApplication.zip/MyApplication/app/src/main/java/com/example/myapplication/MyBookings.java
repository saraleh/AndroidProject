package com.example.myapplication;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.myapplication.adapters.EventRecyclerAdapter;
import com.example.myapplication.events.DataBaseHelperEvents;
import com.example.myapplication.events.Event;

import java.util.ArrayList;
import java.util.List;

public class MyBookings extends AppCompatActivity {

    private AppCompatActivity activity = com.example.myapplication.MyBookings.this;
    private RecyclerView recyclerViewEvents;
    private List<Event> listevent;
    private EventRecyclerAdapter eventsRecyclerAdapter;
    private DataBaseHelperEvents databaseHelper;
    Intent intent;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_bookings);
        getSupportActionBar().setTitle("");
        initViews();
        initObjects();


    }
    /**
     * This method is to initialize views
     */
    private void initViews() {
        recyclerViewEvents = (RecyclerView) findViewById(R.id.recyclerViewBk);
    }

    /**
     * This method is to initialize objects to be used
     */
    private void initObjects() {
        listevent = new ArrayList<>();
        eventsRecyclerAdapter = new EventRecyclerAdapter(listevent);
        RecyclerView.LayoutManager mLayoutManagerr = new LinearLayoutManager(getApplicationContext());
        recyclerViewEvents.setLayoutManager(mLayoutManagerr);
        recyclerViewEvents.setItemAnimator(new DefaultItemAnimator());
        recyclerViewEvents.setHasFixedSize(true);
        recyclerViewEvents.setAdapter(eventsRecyclerAdapter);

        databaseHelper = new DataBaseHelperEvents(activity);

        getDataFromSQLite();
    }

    /**
     * This method is to fetch all user records from SQLite
     */
    private void getDataFromSQLite() {
        // AsyncTask is used that SQLite operation not blocks the UI Thread.
        new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... params) {
                intent = getIntent();
                if (intent.hasExtra("findname")) {
                    String sfindname = intent.getStringExtra("findname");
                    String cat = intent.getStringExtra("catseats");
                    //listevent.clear();
                    listevent.addAll(databaseHelper.checkName(sfindname));
                    for (Event i: listevent)
                    {   if (cat.equals("category1")) i.setSeat1(i.getSeat1()-1);
                        if (cat.equals("category2")) i.setSeat1(i.getSeat2()-1);
                        if (cat.equals("category3")) i.setSeat1(i.getSeat3()-1);
                    }
                }
                return null;

            }

            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);
                eventsRecyclerAdapter.notifyDataSetChanged();
            }
        }.execute();
    }
}