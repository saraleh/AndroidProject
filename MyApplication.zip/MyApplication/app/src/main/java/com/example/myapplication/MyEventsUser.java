package com.example.myapplication;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.widget.ListViewCompat;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplication.adapters.EventRecyclerAdapter;
import com.example.myapplication.events.*;
import com.example.myapplication.login.DatabaseHelper;

import java.util.ArrayList;
import java.util.List;


public class MyEventsUser extends AppCompatActivity {

    /*DataBaseHelperEvents database;
    //ListView listView;
    private RecyclerView recyclerViewEvents;
    private List<Event> listevents;
    private EventRecyclerAdapter eventsRecyclerAdapter;
    private DataBaseHelperEvents databaseHelper;
    Intent i = getIntent();
    String findloc = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_events_liste);

        database = new DataBaseHelperEvents(MyEventsUser.this);
        /*Intent i = getIntent();
        String findloc ="";
        if (i.hasExtra("findloc")){
            findloc = i.getStringExtra("findloc");
            Toast.makeText(MyEventsUser.this, "editText Trouvé", Toast.LENGTH_SHORT).show();}
        listView = (ListView) findViewById(R.id.listViewev);


        List<Event> listeevebts = database.checkLocation(findloc.toString().trim());

        ArrayAdapter<Event> arrayAdapter
                = new ArrayAdapter<Event>(this, android.R.layout.simple_list_item_1 , liste);
        listView.setAdapter(arrayAdapter);

        getSupportActionBar().setTitle("");
        initViews();
        initObjects();


    }

     */


    private AppCompatActivity activity = com.example.myapplication.MyEventsUser.this;
    private RecyclerView recyclerViewEvents;
    private List<Event> listevents;
    private EventRecyclerAdapter eventsRecyclerAdapter;
    private DataBaseHelperEvents databaseHelper;
    Intent intent ;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_events_user);
        getSupportActionBar().setTitle("");
        initViews();
        initObjects();

        Button btnBook= findViewById(R.id.BtnBook);
        EditText edtnamebook = findViewById(R.id.edtNameBook);
        EditText edtcatseats = findViewById(R.id.edtSeats);

        btnBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MyEventsUser.this, MyBookings.class);
                i.putExtra("findname", edtnamebook.getText().toString() );
                i.putExtra("catseats", edtcatseats.getText().toString() );
                startActivity(i);
                Toast.makeText(MyEventsUser.this, "Event booked successfully", Toast.LENGTH_SHORT).show();


            }
        });
    }
    /**
     * This method is to initialize views
     */
    private void initViews() {
        //textViewName = (TextView) findViewById(R.id.textViewName);
        recyclerViewEvents = (RecyclerView) findViewById(R.id.recyclerViewUsers);
    }
    /**
     * This method is to initialize objects to be used
     */
    private void initObjects() {
        listevents = new ArrayList<>();
        eventsRecyclerAdapter = new EventRecyclerAdapter(listevents);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerViewEvents.setLayoutManager(mLayoutManager);
        recyclerViewEvents.setItemAnimator(new DefaultItemAnimator());
        recyclerViewEvents.setHasFixedSize(true);
        recyclerViewEvents.setAdapter(eventsRecyclerAdapter);

        databaseHelper = new DataBaseHelperEvents(activity);

        //listevents.addAll(databaseHelper.checkName("name"));
        //System.out.println("yeeeeeeeeeeeessssssssssssssssssss" + findname);

        getDataFromSQLite();
    }
    /**
     * This method is to fetch all user records from SQLite
     */
    private void getDataFromSQLite() {
        // AsyncTask is used that SQLite operation not blocks the UI Thread.
        new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... params) {
                intent = getIntent();
                if (intent.hasExtra("findname")){
                    String sfindname = intent.getStringExtra("findname");
                    listevents.clear();
                    listevents.addAll(databaseHelper.checkName(sfindname.trim()));}
                    return null;

            }
            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);
                eventsRecyclerAdapter.notifyDataSetChanged();
            }
        }.execute();
    }
}




