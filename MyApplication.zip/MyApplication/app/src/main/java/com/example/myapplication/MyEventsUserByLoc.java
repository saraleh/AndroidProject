package com.example.myapplication;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.myapplication.adapters.EventRecyclerAdapter;
import com.example.myapplication.events.DataBaseHelperEvents;
import com.example.myapplication.events.Event;

import java.util.ArrayList;
import java.util.List;

public class MyEventsUserByLoc extends AppCompatActivity {

        private AppCompatActivity activity = com.example.myapplication.MyEventsUserByLoc.this;
        private RecyclerView recyclerViewEvents;
        private List<Event> listevents;
        private EventRecyclerAdapter eventsRecyclerAdapter;
        private DataBaseHelperEvents databaseHelper;
        Intent intent;


        @Override
        protected void onCreate(@Nullable Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_my_events_user_by_loc);
            getSupportActionBar().setTitle("");
            initViews();
            initObjects();


            Button btnBook= findViewById(R.id.BtnBook);
            EditText edtnamebook = findViewById(R.id.edtNameBook);
            EditText edtcatseats = findViewById(R.id.edtSeats);

            btnBook.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = new Intent(MyEventsUserByLoc.this, MyBookings.class);
                    i.putExtra("findname", edtnamebook.getText().toString() );
                    i.putExtra("catseats", edtcatseats.getText().toString() );
                    startActivity(i);
                    Toast.makeText(MyEventsUserByLoc.this, "Event booked successfully", Toast.LENGTH_SHORT).show();


                }
            });
        }
        /**
         * This method is to initialize views
         */
        private void initViews() {
            recyclerViewEvents = (RecyclerView) findViewById(R.id.recyclerViewUsers);
        }

        /**
         * This method is to initialize objects to be used
         */
        private void initObjects() {
            listevents = new ArrayList<>();
            eventsRecyclerAdapter = new EventRecyclerAdapter(listevents);
            RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
            recyclerViewEvents.setLayoutManager(mLayoutManager);
            recyclerViewEvents.setItemAnimator(new DefaultItemAnimator());
            recyclerViewEvents.setHasFixedSize(true);
            recyclerViewEvents.setAdapter(eventsRecyclerAdapter);
            //recyclerViewEvents.scrollBy(0,9);

            databaseHelper = new DataBaseHelperEvents(activity);

            getDataFromSQLite();
        }

        /**
         * This method is to fetch all user records from SQLite
         */
        private void getDataFromSQLite() {
            // AsyncTask is used that SQLite operation not blocks the UI Thread.
            new AsyncTask<Void, Void, Void>() {
                @Override
                protected Void doInBackground(Void... params) {
                    intent = getIntent();
                    if (intent.hasExtra("findloc")) {
                        String sfindname = intent.getStringExtra("findloc");
                        System.out.println("-----------------------------------------"+sfindname);
                        listevents.clear();
                        listevents.addAll(databaseHelper.checkLocation(sfindname));
                    }
                    return null;

                }

                @Override
                protected void onPostExecute(Void aVoid) {
                    super.onPostExecute(aVoid);
                    eventsRecyclerAdapter.notifyDataSetChanged();
                }
            }.execute();
        }
    }
