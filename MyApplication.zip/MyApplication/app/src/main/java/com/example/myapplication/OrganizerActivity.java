package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.example.myapplication.login.*;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputLayout;

public class OrganizerActivity extends AppCompatActivity {
    MySQLiteOpenHelper DB = new MySQLiteOpenHelper(OrganizerActivity.this);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_organizer);
        EditText emailEdt = findViewById(R.id.etmailorg);
        EditText passwordEdt = findViewById(R.id.etpswdorg);
        EditText fnEdt = findViewById(R.id.etfnorg);
        EditText lnEdt = findViewById(R.id.etlnorg);
        Button loginBtn = findViewById(R.id.btnloginorg);
        Button registerBtn = findViewById(R.id.btnregisterorg);
        Button allusers = findViewById(R.id.btnAllusers);
        inputValidation inputValidation = new inputValidation(OrganizerActivity.this);




       /*
        // calling on click listener for login button.
        registerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String user = emailEdt.toString();
                String pass = passwordEdt.toString();
                String fn = fnEdt.toString();
                String ln = lnEdt.toString();

                if (TextUtils.isEmpty(user) || TextUtils.isEmpty(pass)|| TextUtils.isEmpty(fn)|| TextUtils.isEmpty(ln))
                    Toast.makeText(OrganizerActivity.this, "all fields required", Toast.LENGTH_SHORT).show();
                else
                if (DB.CheckUsernames(user)== false){
                    Boolean inser =  DB.CheckPass(user, pass);
                    //if (inser == true){
                        Toast.makeText(OrganizerActivity.this, "Registered successfully", Toast.LENGTH_SHORT).show();
                        Intent intenta = new Intent(OrganizerActivity.this, MenuOrg.class);
                        startActivity(intenta);

                    //else Toast.makeText(OrganizerActivity.this, "Registration failed ", Toast.LENGTH_SHORT).show();

                }else Toast.makeText(OrganizerActivity.this, "User already exists", Toast.LENGTH_SHORT).show();




            }


          });
        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentb = new Intent(getApplicationContext(), LoginOrg.class);
                startActivity(intentb);
            }
        });

        */
        //login = already have an account


        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i1 = new Intent(OrganizerActivity.this, LoginOrg.class);
                startActivity(i1);
            }
        });

        registerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatabaseHelper databaseHelp = new DatabaseHelper(OrganizerActivity.this);
                User user = new User();

                if (!inputValidation.isInputEditTextFilled(fnEdt, getString(R.string.error_message_name))
                        || !inputValidation.isInputEditTextFilled(emailEdt, getString(R.string.error_message_email))
                        || !inputValidation.isInputEditTextEmail(emailEdt, getString(R.string.error_message_email))
                        || !inputValidation.isInputEditTextFilled(passwordEdt, getString(R.string.error_message_password))) {
                    return;
                }

                else
                    if (!databaseHelp.checkUser(emailEdt.toString().trim())){
                    user.setName(fnEdt.getText().toString().trim());
                    user.setEmail(emailEdt.getText().toString().trim());
                    user.setPassword(passwordEdt.getText().toString().trim());

                    databaseHelp.addUser(user);
                    Toast.makeText(OrganizerActivity.this, "User Added Successfully", Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(OrganizerActivity.this, MenuOrg.class);
                    startActivity(i);

                    } else {
                    // show error message that record already exists
                        Toast.makeText(OrganizerActivity.this, "User Already Exists", Toast.LENGTH_SHORT).show();

            }

            }
        });
        allusers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i3 = new Intent(OrganizerActivity.this, UserListActivity.class);
                startActivity(i3);
            }
        });

    }




}
