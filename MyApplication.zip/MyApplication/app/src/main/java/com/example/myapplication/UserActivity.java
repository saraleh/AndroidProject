package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.myapplication.login.DatabaseHelper;
import com.example.myapplication.login.User;
import com.example.myapplication.login.inputValidation;


public class UserActivity extends AppCompatActivity {

    MySQLiteOpenHelper DB = new MySQLiteOpenHelper(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);


        // Initializing EditTexts and our Button
            EditText emailEdt = findViewById(R.id.idEdtEmail);
            EditText passwordEdt = findViewById(R.id.idEdtPassword);
            EditText fnEdt = findViewById(R.id.idEdtFirstName);
            EditText lnEdt = findViewById(R.id.idEdtLastName);
            Button loginBtn = findViewById(R.id.idBtnLogin);
            Button registerBtn = findViewById(R.id.idBtnRegister);
            Button allusers = findViewById(R.id.idBtnAllusers);
            inputValidation inputValidation = new inputValidation(UserActivity.this);




        // calling on click listener for login button.
        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i1 = new Intent(UserActivity.this, LoginActivity.class);
                startActivity(i1);
            }
        });

        registerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatabaseHelper databaseHelp = new DatabaseHelper(UserActivity.this);
                User user = new User();

                if (!inputValidation.isInputEditTextFilled(fnEdt, getString(R.string.error_message_name))
                        || !inputValidation.isInputEditTextFilled(emailEdt, getString(R.string.error_message_email))
                        || !inputValidation.isInputEditTextEmail(emailEdt, getString(R.string.error_message_email))
                        || !inputValidation.isInputEditTextFilled(passwordEdt, getString(R.string.error_message_password))) {
                    return;
                }

                else
                if (!databaseHelp.checkUser(emailEdt.toString().trim())){
                    user.setName(fnEdt.getText().toString().trim());
                    user.setEmail(emailEdt.getText().toString().trim());
                    user.setPassword(passwordEdt.getText().toString().trim());

                    databaseHelp.addUser(user);
                    Toast.makeText(UserActivity.this, "User Added Successfully", Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(UserActivity.this, MenuUser.class);
                    startActivity(i);

                } else {
                    // show error message that record already exists
                    Toast.makeText(UserActivity.this, "User Already Exists", Toast.LENGTH_SHORT).show();

                }

            }
        });
        allusers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i3 = new Intent(UserActivity.this, UserListActivity.class);
                startActivity(i3);
            }
        });

    }


}
