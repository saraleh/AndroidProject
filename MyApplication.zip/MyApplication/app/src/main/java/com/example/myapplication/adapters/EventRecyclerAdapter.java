package com.example.myapplication.adapters;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.myapplication.R;
import com.example.myapplication.events.Event;
import com.example.myapplication.login.User;

import java.util.List;

public class EventRecyclerAdapter  extends RecyclerView.Adapter<EventRecyclerAdapter.EventViewHolder> {

    private List<Event> listEvents;

    public EventRecyclerAdapter(List<Event>listEvents) {
        this.listEvents = listEvents;
    }

    @Override
    public EventRecyclerAdapter.EventViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // inflating recycler item view
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.activity_event_recycler_adapter, parent, false);

        return new EventRecyclerAdapter.EventViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(EventRecyclerAdapter.EventViewHolder holder, int position) {
        holder.textViewTitle.setText(listEvents.get(position).getTitle());
        holder.textViewType.setText(listEvents.get(position).getType());
        holder.textViewPrice.setText(String.valueOf(listEvents.get(position).getPrix()));
        holder.textViewDate.setText(listEvents.get(position).getDate());
        holder.textViewDescription.setText(listEvents.get(position).getDescription());
        holder.textViewSeats1.setText(String.valueOf(listEvents.get(position).getSeat1()));
        holder.textViewSeats2.setText(String.valueOf(listEvents.get(position).getSeat2()));
        holder.textViewSeats3.setText(String.valueOf(listEvents.get(position).getSeat3()));


    }

    @Override
    public int getItemCount() {
        Log.v(UserRecyclerAdapter.class.getSimpleName(),""+listEvents.size());
        return listEvents.size();
    }


    /**
     * ViewHolder class
     */
    public class EventViewHolder extends RecyclerView.ViewHolder {

        public TextView textViewTitle;
        public TextView textViewType;
        public TextView textViewPrice;
        public TextView textViewDate;
        public TextView textViewDescription;
        public TextView textViewSeats1;
        public TextView textViewSeats2;
        public TextView textViewSeats3;

        public EventViewHolder(View view) {
            super(view);
            textViewTitle = (TextView) view.findViewById(R.id.textViewTitle);
            textViewType = (TextView) view.findViewById(R.id.textViewType);
            textViewPrice = (TextView) view.findViewById(R.id.textViewPrice);
            textViewDate = (TextView) view.findViewById(R.id.textViewDate);
            textViewDescription = (TextView) view.findViewById(R.id.textViewDescription);
            textViewSeats1 = (TextView) view.findViewById(R.id.textViewSeat1);
            textViewSeats2 = (TextView) view.findViewById(R.id.textViewSeats2);
            textViewSeats3 = (TextView) view.findViewById(R.id.textViewSeats3);
        }
    }


}