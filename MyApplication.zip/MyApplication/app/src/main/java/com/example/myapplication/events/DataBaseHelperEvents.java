package com.example.myapplication.events;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.example.myapplication.login.User;

import java.util.ArrayList;
import java.util.List;

public class DataBaseHelperEvents extends SQLiteOpenHelper {

    // Database Version
    private static final int DATABASE_VERSION = 1;

    // Database Name
    private static final String DATABASE_NAME = "EventsManager.db";

    // User table name
    private static final String TABLE_NAME = "event";

    // User Table Columns names

    private static final String COLUMN_ID = "_id";
    private static final String COLUMN_TITLE = "events_title";
    private static final String COLUMN_TYPE = "envent_type";
    private static final String COLUMN_PRIX = "event_prix";
    private static final String COLUMN_DATE = "event_date";
    private static final String COLUMN_DESCRIPTION = "event_description";
    private static final String COLUMN_SEATS1 = "seats_category_1";
    private static final String COLUMN_SEATS2 = "seats_category_2";
    private static final String COLUMN_SEATS3 = "seats_category_3";

     public DataBaseHelperEvents(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);

    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE " + TABLE_NAME +
                " (" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_TITLE + " TEXT, " +
                COLUMN_TYPE + " TEXT, " +
                COLUMN_PRIX + " INTEGER, " +
                COLUMN_DATE + " TEXT, " +
                COLUMN_DESCRIPTION + " TEXT, " +
                COLUMN_SEATS1 + " INTEGER, " +
                COLUMN_SEATS2 + " INTEGER, " +
                COLUMN_SEATS3 + " INTEGER);";
        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }



    public void addEvent(Event event){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COLUMN_TITLE, event.getTitle());
        cv.put(COLUMN_TYPE, event.getType());
        cv.put(COLUMN_PRIX, event.getPrix());
        cv.put(COLUMN_DATE, event.getDate());
        cv.put(COLUMN_DESCRIPTION, event.getDescription());
        cv.put(COLUMN_SEATS1, event.getSeat1());
        cv.put(COLUMN_SEATS2, event.getSeat2());
        cv.put(COLUMN_SEATS3, event.getSeat3());
        long result = db.insert(TABLE_NAME,null, cv);
        if(result == -1){ System.out.println("addEvent Failed");}

    }


    public List<Event> getAllEvents() {
        // array of columns to fetch
        String[] columns = {
                COLUMN_ID,
                COLUMN_TITLE ,
                COLUMN_TYPE,
                COLUMN_PRIX ,
                COLUMN_DATE,
                COLUMN_DESCRIPTION ,
                COLUMN_SEATS1 ,
                COLUMN_SEATS2 ,
                COLUMN_SEATS3
        };
        // sorting orders
        String sortOrder =
                COLUMN_TITLE + " ASC";
        List<Event> eventList = new ArrayList<Event>();

        SQLiteDatabase db = this.getReadableDatabase();

        // query the user table
        /**
         * Here query function is used to fetch records from user table this function works like we use sql query.
         * SQL query equivalent to this query function is
         * SELECT user_id,user_name,user_email,user_password FROM user ORDER BY user_name;
         */
        Cursor cursor = db.query(TABLE_NAME, //Table to query
                columns,    //columns to return
                null,        //columns for the WHERE clause
                null,        //The values for the WHERE clause
                null,       //group the rows
                null,       //filter by row groups
                sortOrder); //The sort order


        // Traversing through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                Event event = new Event();
                event.setTitle(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TITLE)));
                event.setType(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TYPE)));
                event.setPrix(Integer.parseInt(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PRIX))));
                event.setDate(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DATE)));
                event.setDescription(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DESCRIPTION)));
                event.setSeat1(Integer.parseInt(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_SEATS1))));
                event.setSeat2(Integer.parseInt(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_SEATS2))));
                event.setSeat3(Integer.parseInt(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_SEATS3))));


                // Adding user record to list
                eventList.add(event);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();

        // return user list
        return eventList;
    }

    /**
     * This method to update user record
     *
     */
    public void updateEvent(String row_id, String title, String type, int prix, String date, String description, int seat1, int seat2, int seat3){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_TITLE, title);
        cv.put(COLUMN_TYPE, type);
        cv.put(COLUMN_PRIX, prix);
        cv.put(COLUMN_DESCRIPTION, description);
        cv.put(COLUMN_SEATS1, seat1);
        cv.put(COLUMN_SEATS2, seat2);
        cv.put(COLUMN_SEATS3, seat3);

        long result = db.update(TABLE_NAME, cv, "_id=?", new String[]{row_id});
        if(result == -1){ System.out.println("updateEvent Failed");}

        db.close();

    }


    /**
     * This method is to delete
     */
    public void deleteEvent(Event event){
        SQLiteDatabase db = this.getWritableDatabase();
        // delete event by id
        db.delete(TABLE_NAME, COLUMN_ID + " = ?",
                new String[]{String.valueOf(event.getId())});
        db.close();

    }


    /**
     * This method to check user exist or not

     */
    public boolean checkEvent(String title) {

        // array of columns to fetch
        String[] columns = {
                COLUMN_ID
        };
        SQLiteDatabase db = this.getReadableDatabase();

        // selection criteria
        String selection = COLUMN_TITLE + " = ?";

        // selection argument
        String[] selectionArgs = {title};

        // query user table with condition
        /**
         * Here query function is used to fetch records from user table this function works like we use sql query.
         * SQL query equivalent to this query function is
         * SELECT user_id FROM user WHERE user_email = 'jack@androidtutorialshub.com';
         */
        Cursor cursor = db.query(TABLE_NAME, //Table to query
                columns,                    //columns to return
                selection,                  //columns for the WHERE clause
                selectionArgs,              //The values for the WHERE clause
                null,                       //group the rows
                null,                      //filter by row groups
                null);                      //The sort order
        int cursorCount = cursor.getCount();
        cursor.close();
        db.close();

        if (cursorCount > 0) {
            return true;
        }

        return false;
    }

    public List<Event> checkName(String name) {

        // array of columns to fetch
        String[] columns = {
                COLUMN_ID
        };
        SQLiteDatabase db = this.getReadableDatabase();

        // selection criteria
        String selection = COLUMN_TITLE + " = ?";

        // selection argument
        String[] selectionArgs = {name};

        // query user table with condition
        List<Event> eventList = new ArrayList<Event>();
        String sortOrder =
                COLUMN_TITLE + " ASC";

       String selectQuery = "SELECT  * FROM " + TABLE_NAME + " WHERE  " + COLUMN_TITLE + " = '" + name +"'";
       Cursor cursor= db.rawQuery(selectQuery,null);
        if (cursor.moveToFirst()) {
            do {
                Event event = new Event();
                event.setTitle(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TITLE)));
                event.setType(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TYPE)));
                event.setPrix(Integer.parseInt(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PRIX))));
                event.setDate(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DATE)));
                event.setDescription(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DESCRIPTION)));
                event.setSeat1(Integer.parseInt(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_SEATS1))));
                event.setSeat2(Integer.parseInt(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_SEATS2))));
                event.setSeat3(Integer.parseInt(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_SEATS3))));


                // Adding event record to list
                eventList.add(event);
                System.out.println("I am checkLocation------------------------------------------------");
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();

        return eventList;
    }

    public List<Event> checkLocation(String name) {


        SQLiteDatabase db = this.getReadableDatabase();

        // query user table with condition
        List<Event> eventList = new ArrayList<Event>();


        String selectQuery = "SELECT  * FROM " + TABLE_NAME + " WHERE  " + COLUMN_TYPE + " = '" + name +"'";
        Cursor cursor= db.rawQuery(selectQuery,null);
        if (cursor.moveToFirst()) {
            do {
                Event event = new Event();
                event.setTitle(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TITLE)));
                event.setType(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TYPE)));
                event.setPrix(Integer.parseInt(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PRIX))));
                event.setDate(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DATE)));
                event.setDescription(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DESCRIPTION)));
                event.setSeat1(Integer.parseInt(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_SEATS1))));
                event.setSeat2(Integer.parseInt(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_SEATS2))));
                event.setSeat3(Integer.parseInt(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_SEATS3))));


                // Adding event record to list
                eventList.add(event);
                //System.out.println("I am checkLocation------------------------------------------------");
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();

        return eventList;
    }

}
