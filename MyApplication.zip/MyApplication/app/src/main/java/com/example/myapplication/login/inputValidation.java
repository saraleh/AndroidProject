package com.example.myapplication.login;

import android.app.Activity;
import android.content.Context;

import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class inputValidation {
    private Context context;

    /**
     * constructor
     *
     * @param context
     */
    public inputValidation(Context context) {
        this.context = context;
    }

    /**
     * method to check InputEditText filled .
     *
     * @param textInputEditText
     * @param message
     * @return
     */
    public boolean isInputEditTextFilled(EditText textInputEditText, String message) {
        String value = textInputEditText.toString().trim();
        if (value.isEmpty()) {
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
            hideKeyboardFrom(textInputEditText);
            Toast.makeText(context, "All fields required", Toast.LENGTH_SHORT).show();
            return false;

        }


        return true;
    }


    /**
     * method to check InputEditText has valid email .

     */
    public  boolean isInputEditTextEmail(EditText EditText, String message) {
        String value = EditText.getText().toString().trim();
        if (value.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(value).matches()) {
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
            Toast.makeText(context, "Email Address Incorrect", Toast.LENGTH_SHORT).show();
            return false;

        }
        return true;
    }

    public boolean isInputEditTextMatches(EditText textInputEditText1, EditText textInputEditText2,  String message) {
        String value1 = textInputEditText1.getText().toString().trim();
        String value2 = textInputEditText2.getText().toString().trim();
        if (!value1.contentEquals(value2)) {
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
            hideKeyboardFrom(textInputEditText2);
            Toast.makeText(context, "Error Enabled", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    /**
     * method to Hide keyboard
     *
     * @param view
     */
    private void hideKeyboardFrom(View view) {
        InputMethodManager imm = (InputMethodManager) context.getSystemService(Activity.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(view.getWindowToken(), WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
    }
}